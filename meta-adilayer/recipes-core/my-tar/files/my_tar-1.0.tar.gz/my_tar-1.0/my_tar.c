#include "archive.h"
#include "utils.h"
#include <fcntl.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include "my_string.h"

off_t find_eof_position(int archive_fd) {
    off_t file_size = lseek(archive_fd, 0, SEEK_END);
    if (file_size == -1) {
        perror("Error seeking to end of archive");
        return -1;
    }

    off_t offset = file_size - 1024;  // Two 512-byte blocks
    if (offset < 0) {
        offset = 0;
    }

    lseek(archive_fd, offset, SEEK_SET);

    char eof_marker[1024];
    ssize_t bytes_read = read(archive_fd, eof_marker, 1024);
    if (bytes_read == -1) {
        perror("Error reading EOF markers");
        return -1;
    }

    bool has_eof = true;
    for (ssize_t i = 0; i < bytes_read; i++) {
        if (eof_marker[i] != 0) {
            has_eof = false;
            break;
        }
    }

    if (has_eof) {
        return offset;
    } else {
        return file_size;
    }
}


int main(int argc, char** argv) {
    ArgHandel args = argParse(argc, argv);
    
    if(args.archive == NULL){
        printf("Please specify archive file name with -f flag\n");
        return 1;
    }


    if (args.createC || args.newerU || args.appendR) {
        if (args.paths[0] == NULL) {
            printf("Please specify files to be added to archive\n");
            return 1;
        }

        int output;
        if (args.createC) {
            output = open(args.archive,  O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
            if (output == -1) {
                printf("my_tar: Cannot create %s\n", args.archive);
                return 1;
            }
        }
        else {
            output = open(args.archive, O_RDWR);
            if (output == -1) {
                printf("my_tar: Cannot open %s\n", args.archive);
                return 1;
            }

            // For append or update, position the file descriptor appropriately
            off_t append_position = find_eof_position(output);
            if (append_position == -1) {
                close(output);
                return 1;
            }

            // Move the file descriptor to the append position
            if (lseek(output, append_position, SEEK_SET) == -1) {
                perror("Error seeking to append position");
                close(output);
                return 1;
            }
        }

        char root[1000];
        for (int i = 0; args.paths[i] != NULL; i++) {
            my_strcpy(root, args.paths[i]);

            if (args.newerU) {
                FileSearch searchinfo = {.filename = args.paths[i], .found=false};
                extract(args.archive, false, false, &searchinfo);
                writeArchive(output, root, true, &searchinfo);
            }
            else {
                writeArchive(output, root, true, NULL);
            }
        }

        // Write the EOF markers once after processing all files
        char eof[1024] = {0};
        write(output, eof, sizeof(eof));

        close(output);
    }
    else if(args.extract || args.listT){
        bool status = extract(args.archive, args.listT, args.extract, NULL);
        if(!status){
            printf("my_tar: Cannot open %s\n", args.archive);
            return 1;
        }
    }
    else{
        printf("No argument specified");
    }
    return 0;
}
