#include <stdlib.h>
#include "utils.h"
#include "archive.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

void to_octal_string(char* buffer, unsigned long num, size_t size) {
    buffer[size - 1] = '\0';
    for (int i = size - 2; i >= 0; --i) {
        buffer[i] = (num & 7) + '0';
        num >>= 3;
    }
}
void to_octal_checksum(unsigned long num, char *chksum) {
    for (int i = 0; i < 6; i++) {
        chksum[i] = '0';
    }
    int i = 5;
    while (num > 0 && i >= 0) {
        chksum[i] = (num % 8) + '0';
        num /= 8;
        i--;
    }
    chksum[6] = '\0';
    chksum[7] = ' ';
}

size_t from_octal_string(const char *octal_str) {
    unsigned long result = 0;
    while (*octal_str) {
        if (*octal_str < '0' || *octal_str > '7') {
            return 0;
        }
        result = (result << 3) | (*octal_str - '0');
        octal_str++;
    }
    return result;
}


unsigned long calculate_checksum(struct posix_header *header) {
    unsigned long checksum = 0;
    const unsigned char *bytes = (const unsigned char *)header;

    for (size_t i = 0; i < sizeof(struct posix_header); i++) {
        checksum += bytes[i];
    }

    for (size_t i = 148; i < 156; i++) {
        checksum -= bytes[i];
        checksum += ' '; 
    }

    return checksum;
}

char* readContent(const char* file_path, size_t file_size){
    int file = open(file_path, O_RDONLY); 
    if (file == -1) {
        return NULL;
    }
    char *buffer;
    buffer = (char *)malloc(file_size);
    read(file, buffer, file_size);
    close(file);
    return buffer;
}


ArgHandel argParse(int argc, char** argv){
    ArgHandel args = {false, false, false, false, false, 0x0, 0x0};    
    args.paths = malloc(sizeof(char*) * argc);
    for(int i=0; i<argc; i++) args.paths[i] = 0;

    for(int i=1; i<argc; i++){
        char* arg = argv[i];
        bool skip = false;
        if(arg[0] == '-'){
            for(int j=0; arg[j]!='\0'; j++){
                if(arg[j] == 'c') args.createC = true;
                if(arg[j] == 'r') args.appendR = true;
                if(arg[j] == 't') args.listT = true;
                if(arg[j] == 'u') args.newerU = true;
                if(arg[j] == 'x') args.extract = true;
                if(arg[j] == 'f') {
                    args.archive = argv[i+1];
                    skip = true;
                }
            }
        }
        else{
            int i;
            for(i=0; args.paths[i] != 0x0; i++);
            args.paths[i] = arg;
        }
        if(skip)i++;
    }

    return args;
}

void printArg(ArgHandel args){
    printf("Create -c: %d\n", args.createC);
    printf("Append -r: %d\n", args.appendR);
    printf("List -t: %d\n", args.listT);
    printf("Append Newer -t: %d\n", args.newerU);
    printf("Extract -x: %d\n", args.extract);
    if(args.archive != 0x0)printf("Archive Name: %s\n", args.archive);
    printf("File Name: ");
    if(args.archive == 0x0) return;
    for(int i=0; args.paths[i] != 0x0; i++){
        printf("%s, ", args.paths[i]);
    }
}
