#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <pwd.h>
#include <unistd.h>
#include <dirent.h>
#include <grp.h>
#include <stdbool.h>
#include <errno.h>
#include <utime.h>

#include "utils.h"
#include "archive.h"
#include "my_string.h"


void writeArchiveFileContent(int archive_fd, int file_fd, size_t file_size) {
    char buf[512];
    size_t bytes_remaining = file_size;

    // Read and write the file content
    while (bytes_remaining > 0) {
        size_t bytes_to_read = bytes_remaining < sizeof(buf) ? bytes_remaining : sizeof(buf);
        ssize_t bytes_read = read(archive_fd, buf, bytes_to_read);
        if (bytes_read <= 0) {
            perror("Error reading from archive");
            return;
        }
        if (file_fd >= 0) {
            ssize_t bytes_written = write(file_fd, buf, bytes_read);
            if (bytes_written <= 0) {
                perror("Error writing to file");
                return;
            }
        }
        bytes_remaining -= bytes_read;
    }

    // Skip padding bytes to align to the next 512-byte boundary
    ssize_t padding = (512 - (file_size % 512)) % 512;
    if (padding > 0) {
        // Read and discard padding bytes
        char pad[512];
        ssize_t bytes_read = read(archive_fd, pad, padding);
        if (bytes_read != padding) {
            perror("Error reading padding from archive");
            return;
        }
    }
}

bool extract(char* archive_filename, bool list, bool extract, FileSearch* filesearch) {
    char buffer[512];
    int archive_fd = open(archive_filename, O_RDONLY);
    if (archive_fd == -1) {
        perror("Error opening archive file");
        return false;
    }

    while (true) {
        ssize_t bytes_read = read(archive_fd, buffer, sizeof(buffer));
        if (bytes_read == 0) break;  // End of file
        if (bytes_read < 0) {
            perror("Error reading archive header");
            close(archive_fd);
            return false;
        }

        bool is_end_of_archive = true;
        for (int i = 0; i < 512; i++) {
            if (buffer[i] != 0) {
                is_end_of_archive = false;
                break;
            }
        }
        if (is_end_of_archive) {
            break;
        }

        struct posix_header* header = (struct posix_header*)buffer;

        // Construct the full path
        char fullpath[1024] = {0};
        if (my_strlen(header->prefix) > 0) {
            my_strcat(fullpath, header->prefix);
            my_strcat(fullpath, "/");
        }
        my_strcat(fullpath, header->name);

        if (filesearch != NULL) {
            if (my_strcmp(fullpath, filesearch->filename) == 0) {
                filesearch->mtime = from_octal_string(header->mtime);
                filesearch->found = true;
            }
        }

        // Handle directories
        if (header->typeflag == '5') {
            if (list) printf("%s\n", fullpath);
            if (extract) {
                int status = mkdir(fullpath, from_octal_string(header->mode));
                if (status == -1 && errno != EEXIST) {
                    perror("Error creating directory");
                    close(archive_fd);
                    return false;
                }
            }
        }
        // Handle regular files
        else if (header->typeflag == '0' || header->typeflag == '\0') {
            if (list) printf("%s\n", fullpath);

            int file_fd = -1;
            if (extract) {
                file_fd = open(fullpath, O_WRONLY | O_CREAT | O_TRUNC, from_octal_string(header->mode));
                if (file_fd < 0) {
                    perror("Error creating file");
                    close(archive_fd);
                    return false;
                }
            }
            writeArchiveFileContent(archive_fd, file_fd, from_octal_string(header->size));
            if (file_fd >= 0) close(file_fd);
        }
        // Handle symlinks
        else if (header->typeflag == '2') {
            if (list) printf("%s -> %s\n", fullpath, header->linkname);
            if (extract) {
                int status = symlink(header->linkname, fullpath);
                if (status == -1) {
                    perror("Error creating symlink");
                    close(archive_fd);
                    return false;
                }
            }
        } else {
            // Skip unsupported file types or special files
            size_t file_size = from_octal_string(header->size);
            size_t padding = (512 - (file_size % 512)) % 512;
            // Move the archive_fd past the file content and padding
            lseek(archive_fd, file_size + padding, SEEK_CUR);
            continue;
        }

        // Update file metadata if extracting
        if (extract) {
            struct utimbuf new_time = {
                .actime = time(NULL),
                .modtime = from_octal_string(header->mtime)
            };
            if (chown(fullpath, from_octal_string(header->uid), from_octal_string(header->gid)) == -1) {
                perror("Error setting ownership");
                close(archive_fd);
                return false;
            }
            if (utime(fullpath, &new_time) == -1) {
                perror("Error setting modification time");
                close(archive_fd);
                return false;
            }
        }
    }
    close(archive_fd);
    return true;
}

char getFileType(mode_t filemode) {
    if (S_ISREG(filemode)) return '0';  // Regular file
    if (S_ISLNK(filemode)) return '2';  // Symbolic link
    if (S_ISBLK(filemode)) return '4';  // Block device
    if (S_ISDIR(filemode)) return '5';  // Directory
    if (S_ISFIFO(filemode)) return '6'; // FIFO/pipe
    return 0;
}

bool create_file_header(struct posix_header *header, const char* file_path, size_t *file_size) {
    struct stat file_info;
    if (lstat(file_path, &file_info) == -1) {
        return false;
    }

    int slashPos = my_strlen(file_path) - 1;
    for(; slashPos >= 0; slashPos--) {
        if (file_path[slashPos] == '/') break;
    }

    if(slashPos != -1)my_strncpy(header->prefix, file_path, slashPos);
    my_strcpy(header->name, file_path + slashPos + 1);
    if (S_ISDIR(file_info.st_mode)) {
        int name_len = my_strlen(header->name);
        header->name[name_len] = '/';
        header->name[name_len + 1] = '\0';
    }

    to_octal_string(header->mode, file_info.st_mode & (S_IRWXU | S_IRWXG | S_IRWXO), sizeof(header->mode));
    to_octal_string(header->uid, file_info.st_uid, sizeof(header->uid));
    to_octal_string(header->gid, file_info.st_gid, sizeof(header->gid));
    to_octal_string(header->size, file_info.st_size, sizeof(header->size));
    *file_size = file_info.st_size;

    to_octal_string(header->mtime, file_info.st_mtime, sizeof(header->mtime));

    header->typeflag = getFileType(file_info.st_mode);

    if (S_ISLNK(file_info.st_mode)) {
        char target_path[100];
        ssize_t len = readlink(file_path, target_path, sizeof(target_path) - 1);
        if (len != -1) {
            target_path[len] = '\0';
            my_strcpy(header->linkname, target_path);
        }
    }

    my_strcpy(header->magic, "ustar  ");
    my_strcpy(header->version, "00");
    header->version[2] = ' ';

    struct passwd *upwd = getpwuid(file_info.st_uid);
    struct group *gpwd = getgrgid(file_info.st_gid);
    my_strcpy(header->uname, upwd->pw_name);
    my_strcpy(header->gname, gpwd->gr_name);

    unsigned long checksum = calculate_checksum(header);
    to_octal_checksum(checksum, header->chksum);
    return true;
}

void writeFileContentArchive(const char* file_path, int archive_fd, size_t file_size) {
    char buf[512];
    int file_fd = open(file_path, O_RDONLY);
    if (file_fd == -1) {
        perror("Error opening file");
        return;
    }

    size_t bytes_remaining = file_size;
    while (bytes_remaining > 0) {
        ssize_t bytes_to_read = bytes_remaining < sizeof(buf) ? bytes_remaining : sizeof(buf);
        ssize_t bytes_read = read(file_fd, buf, bytes_to_read);
        if (bytes_read <= 0) {
            perror("Error reading file");
            close(file_fd);
            return;
        }
        ssize_t bytes_written = write(archive_fd, buf, bytes_read);
        if (bytes_written <= 0) {
            perror("Error writing to archive");
            close(file_fd);
            return;
        }
        bytes_remaining -= bytes_read;
    }

    size_t padding = (512 - (file_size % 512)) % 512;
    if (padding > 0) {
        char pad[512] = {0};
        ssize_t bytes_written = write(archive_fd, pad, padding);
        if (bytes_written <= 0) {
            perror("Error writing padding to archive");
            close(file_fd);
            return;
        }
    }

    close(file_fd);
}

int writeArchive(int out_fd, char *root_dir, bool level1_root, FileSearch* filesearch){
    size_t file_size;

    if(level1_root){
        struct posix_header header = {0};
        bool status = create_file_header(&header, root_dir, &file_size);
        if(!status){
            fprintf(stderr, "my_tar: %s: Cannot stat: No such file or directory\n", root_dir);
            return -1;
        }
        
        if(filesearch != NULL){
            if(filesearch->found && filesearch->mtime >= (time_t)from_octal_string(header.mtime)){
                return 0;
            }
        }
        

        write(out_fd, &header, sizeof(struct posix_header));
        char *buf[1024] = {0};
        write(out_fd, buf, 512 - sizeof(struct posix_header));

        if(header.typeflag == '0'){
            writeFileContentArchive(root_dir, out_fd, file_size);
        }
    }

    DIR *dp;
    struct dirent *ep;     
    dp = opendir (root_dir);
    if (dp != NULL){
        my_strcat(root_dir, "/"); 
        while ((ep = readdir (dp)) != NULL){
            if(my_strcmp(ep->d_name, ".")==0 || my_strcmp(ep->d_name, "..")==0) continue;
            char file_path[200];
            my_strcpy(file_path, root_dir);
            my_strcat(file_path, ep->d_name); 
            struct posix_header header = {0};
            create_file_header(&header, file_path, &file_size);
            write(out_fd, &header, sizeof(struct posix_header));
            char *buf[1024] = {0};
            write(out_fd, buf, 512 - sizeof(struct posix_header));
            if(header.typeflag == '0'){
                writeFileContentArchive(file_path, out_fd, file_size);
            }
            if(header.typeflag == '5'){
                char new_root[1000];
                my_strcpy(new_root,root_dir);
                my_strcat(new_root, header.name);
                writeArchive(out_fd, new_root, false, NULL);
            }
        }
              
        closedir (dp);
        return 0;
    }
    else{
        return -1;
    }
}
