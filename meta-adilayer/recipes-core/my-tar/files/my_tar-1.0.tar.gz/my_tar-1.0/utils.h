#ifndef _UTILS_H
#define _UTILS_H
#include "archive.h"

typedef struct{
    bool createC;
    bool appendR;
    bool listT;
    bool newerU;
    bool extract;
    char* archive;
    char** paths;
}ArgHandel;

void to_octal_string(char* buffer, unsigned long num, size_t size);
void to_octal_checksum(unsigned long num, char *chksum);
size_t from_octal_string(const char *octal_str);
unsigned long calculate_checksum(struct posix_header *header);
char* readContent(const char* file_path, size_t file_size);
ArgHandel argParse(int argc, char** argv);
void printArg(ArgHandel args);

#endif

